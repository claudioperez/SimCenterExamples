function postprocess()

fid = fopen('liquedispResults.out','w');
% nodes = load('nodesInfo.dat');
% elems = load('elementInfo.dat');
% solidElts = elems(:,1);



%----------------------DISPLACEMENTS----------------------------------

displacements = load('out_tcl/displacement.out');

allTimes = displacements(:,1);
displacements(:,1) = [];

[numSteps,numDisps] = size(displacements);
numNodes = numDisps/2;

%liqEle = 48;
%liqNode = liqEle*4 + 4;
liqNode = 1

%liqNode = 10


for i = 1:numSteps

	u = reshape( displacements(i,:), 2, numNodes );
	for j=liqNode%1:numNodes
		fprintf(fid,'%d \t %-12.8e %-12.8e \n', j, u(:,j));
    end
end

clear displacements

fprintf(2,'* %s\n','Done with displacements ...')


fclose(fid);




%----------------------PORE PRESSURES----------------------------------
fid = fopen('liquepwpResults.out','w');

porePress = load('out_tcl/porePressure.out');

allTimes = porePress(:,1);
porePress(:,1) = [];

[numSteps,numNodes] = size(porePress);
ppRatio = zeros(numSteps,numNodes);

iniPress = reshape(porePress(1,:), 1, numNodes);

for i = 1:numSteps

	u = reshape( porePress(i,:), 1, numNodes );
	%exPWP(i,:) = abs(u - iniPress); %exPWP
    exPWP(i,:) = u; %PWP
	for j=liqNode%1:numNodes
		fprintf(fid,'%d \t %-12.8e \n', j, exPWP(i,j));
        %fprintf(fid,'%d \t %-12.8e \n', j, u(:,j));
	end

end

fprintf(2,'* %s\n','Done with porepressure ...')

fclose(fid);

%------------------------STRESSES-------------------------------------
% 
% stress = load('stress.out');
% stress(:,1) = [];
% 
% [nStep,nStress] = size(stress);
% nElem = nStress/7;
% 
% for k = 1:nStep
%     fprintf(fid,'GaussPoints "stress" ElemType Hexahedra\n');
% 	fprintf(fid,'Number of Gauss Points: 1\n');
% 	fprintf(fid,'Natural Coordinate: Internal\n');
% 	fprintf(fid,'End Gausspoints\n\n');
% 	fprintf(fid,'Result "Gauss Point Stress" "Loading_Analysis"\t%12.5g', allTimes(k));
%     fprintf(fid,'\tMatrix OnGaussPoints "stress"\n');
% 	fprintf(fid,'Values\n');
% 
%     gp = reshape(stress(k,:), 7, nElem);
% 
%     for j = 1:nElem
% 		eleID = solidElts(j,1);
%         fprintf(fid,'%6.0f  ', eleID);
% 		fprintf(fid,'%12.6g %12.6g %12.6g %12.6g %12.6g %12.6g \n', gp(1:6,j));
% 	end
% 	fprintf(fid,'End Values \n');
% 	fprintf(fid,'\n');
% end
% 
% clear stress gp
% 
% fprintf(2,'* %s\n','Done with stress ...')
% 
% %----------------------PORE PRESSURE RATIO----------------------------------
% stress = load('Gstress.out');
% stress(:,1) = [];
% stress = stress(1,:);
% [nStep,nStress] = size(stress);
% nElem = nStress/7;
% sNot = reshape(stress(1,:), 7, nElem);
% clear stress
% sVnot = sNot(2,:);
% 
% iniStress = ppRatio;
% % local coordinate vectors
% xi  =  0.125*[-1; 1; 1;-1;-1; 1; 1;-1];
% et  =  0.125*[-1;-1; 1; 1;-1;-1; 1; 1];
% ze  =  0.125*[-1;-1;-1;-1; 1; 1; 1; 1];
% hst =  0.125*[ 1;-1; 1;-1; 1;-1; 1;-1];
% hut =  0.125*[ 1; 1;-1;-1;-1;-1; 1; 1];
% hus =  0.125*[ 1;-1;-1; 1;-1; 1; 1;-1];
% hstu = 0.125*[-1; 1;-1; 1; 1;-1; 1;-1];
% 
% for i = 1:nElem
% 	for j = 1:8
% 		x(j) = nodes(elems(i,j+1),2);
% 		y(j) = nodes(elems(i,j+1),3);
% 		z(j) = nodes(elems(i,j+1),4);
% 	end
% 
% 	% define coefficents
%     a1 = x*xi;
%     a2 = x*et;
%     a3 = x*ze;
%     a4 = x*hut;
%     a5 = x*hus;
%     a6 = x*hst;
%     a7 = x*hstu;
%     
%     b1 = y*xi;
%     b2 = y*et;
%     b3 = y*ze;
%     b4 = y*hut;
%     b5 = y*hus;
%     b6 = y*hst;
%     b7 = y*hstu;
%     
%     c1 = z*xi;
%     c2 = z*et;
%     c3 = z*ze;
%     c4 = z*hut;
%     c5 = z*hus;
%     c6 = z*hst;
%     c7 = z*hstu;
%     
%     % define coefficent vectors
%     e1 = [a1;b1;c1];
%     e2 = [a2;b2;c2];
%     e3 = [a3;b3;c3];
%     e4 = [a4;b4;c4];
%     e5 = [a5;b5;c5];
%     e6 = [a6;b6;c6];
%     e7 = [a7;b7;c7];
%     
%     % jacobian terms
%     J0 = e1'*cross(e2,e3);
%     J1 = e1'*cross(e2,e5) + e1'*cross(e6,e3);
%     J2 = e1'*cross(e2,e4) + e6'*cross(e2,e3);
%     J3 = e5'*cross(e2,e3) + e1'*cross(e4,e3);
%     J4 = e7'*cross(e2,e3) + e4'*cross(e5,e2) + e4'*cross(e3,e6);
%     J5 = e1'*cross(e7,e3) + e4'*cross(e5,e1) + e3'*cross(e5,e6);
%     J6 = e1'*cross(e2,e7) + e4'*cross(e1,e6) + e2'*cross(e5,e6);
%     J7 = -e1'*cross(e5,e6);
%     J8 = -e4'*cross(e2,e6);
%     J9 = -e4'*cross(e5,e3);
%     J10 = e2'*cross(e4,e7);
%     J11 = -e3'*cross(e4,e7);
%     J12 = e3'*cross(e5,e7);
%     J13 = -e1'*cross(e5,e7);
%     J14 = e1'*cross(e6,e7);
%     J15 = -e2'*cross(e6,e7);
%     J16 = 2*e4'*cross(e5,e6);
%     J17 = e7'*cross(e5,e6);
%     J18 = e4'*cross(e7,e6);
%     J19 = e4'*cross(e5,e7);
% 
% 	nodeStress = sVnot(i)*(J0 + (J1*xi + J2*et + J3*ze + J7 + J8 + J9)/3.0 ...
%                      + (J4*hut + J5*hus + J6*hst + J10*ze + J11*et + J12*xi + J13*ze + J14*et + J15*xi)/9.0 ...
% 					 + (J16*hstu + J17*hut + J18*hus + J19*hst)/27.0);
% 
% 	for j = 1:8
%         iniStress(:,elems(i,j+1)) = iniStress(:,elems(i,j+1)) + nodeStress(j);
% 	end
% end
% 
% iniStress = 2*iniStress;
% 
% ppRatio = abs(exPWP./iniStress);
% 	
% [numSteps,numNodes] = size(ppRatio);
% 
% for i = 1:numSteps
% 	fprintf(fid,'Result "a.  Nodal PorePressureRatio" "Loading_Analysis"\t%12.5g Scalar OnNodes\n', allTimes(i));
% 	fprintf(fid,'ComponentNames "PorePressureRatio" \n');
% 	fprintf(fid,'Values\n');
% 	
% 	u = reshape( ppRatio(i,:), 1, numNodes );
% 	for j=1:numNodes
% 		fprintf(fid,'%d \t %-12.8e \n', j, u(:,j));
% 	end
% 	fprintf(fid,'End Values \n') ;
% 	fprintf(fid,' \n') ;
% end
% 
% fprintf(2,'* %s\n','Done with porepressure ratio...')
% 
% %----------------------END OF RESULT FILE ----------------------------------
% fclose(fid);
% 
% return
