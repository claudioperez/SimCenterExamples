clear
clc
close all

dir = pwd;


openseesDir = "./data-opensees/";
s3harkDir = "./data-s3hark/";
%s3harkDir = "/Users/simcenter/Library/Application Support/SimCenter/s3hark/analysis";

% go to opensees dir to calc results
cd(openseesDir)
copyfile([dir,'/','postprocess.m'])
postprocess();
cd(dir)

% go to s3hark dir to calc results
cd(s3harkDir)
copyfile([dir,'/','postprocess.m'])
postprocess();

% go back to parent dir
cd(dir)

% load opensees results
displacementsos = load(strcat(openseesDir,"/out_tcl/displacement.out"));
allTimesos = displacementsos(:,1);
dispos = load(strcat(openseesDir,'/liquedispResults.out'));
pwpos = load(strcat(openseesDir,'/liquepwpResults.out'));

% load s3hark results
displacements = load(strcat(s3harkDir,'/out_tcl/displacement.out'));
allTimess3hark = displacements(:,1);
disps3hark = load(strcat(s3harkDir,'/liquedispResults.out'));
pwps3hark = load(strcat(s3harkDir,'/liquepwpResults.out'));



% plot displacement in x1 direction of the node at the middle of the
% liquefied layer

fig=figure('Position',[100, 100, 1000, 900])

subplot(3,1,1)
hold on
plot(allTimess3hark,disps3hark(:,2),'r-') %x
plot(allTimesos(1:200:end),dispos(1:200:end,2),'b+') %x
l=legend('{\its^{3}hark}','OpenSees')
l.FontSize = 17;
set(gca,'FontSize',17, 'FontName', 'Times')
xlabel('Time(s)')
ylabel('Disp-x1(m)')
box on
grid on


% plot displacement in x2 direction of the node at the middle of the
% liquefied layer
subplot(3,1,2)
hold on
plot(allTimess3hark,disps3hark(:,3),'r-') %z
plot(allTimesos(1:200:end),dispos(1:200:end,3),'b+') %z
l=legend('{\its^{3}hark}','OpenSees')
l.FontSize = 17;
set(gca,'FontSize',17, 'FontName', 'Times')
xlabel('Time(s)')
ylabel('Disp-x2(m)')
box on
grid on


% plot pore pressure of the node at the middle of the
% liquefied layer
subplot(3,1,3)
hold on
plot(allTimess3hark(1:5:end),pwps3hark(1:5:end,2),'r-')
plot(allTimesos(1:200:end),pwpos(1:200:end,2),'b+')
l=legend('{\its^{3}hark}','OpenSees')
l.FontSize = 17;
set(gca,'FontSize',17, 'FontName', 'Times')
xlabel('Time(s)')
ylabel('pwp(kPa)')
box on
grid on

print('3DFreefield.pdf','-dpdf')
print('3DFreefield.png','-dpng')



